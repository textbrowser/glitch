#ifndef _QTNQC_LIMITS_H_
#define _QTNQC_LIMITS_H_

#define MAX_TASKS (10 - 1) /* There must be a main() task. */
#define MAX_FUNCTIONS 16
#define MAX_SUBROUTINES 8

#endif
