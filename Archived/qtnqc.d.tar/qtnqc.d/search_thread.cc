#include <search_thread.h>

/*
** -- search_thread() --
*/

search_thread::search_thread(void)
{
}

/*
** -- ~search_thread() --
*/

search_thread::~search_thread()
{
}

/*
** -- run() --
*/

void search_thread::run(void)
{
}

/*
** -- set_search_how() --
*/

void search_thread::set_search_how(const int how)
{
  search_how = how;
}
